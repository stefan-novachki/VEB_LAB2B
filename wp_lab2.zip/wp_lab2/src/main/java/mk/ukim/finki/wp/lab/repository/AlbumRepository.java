package mk.ukim.finki.wp.lab.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AlbumRepository extends JpaRepository {
}
