package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {

    public static List<Artist> listArtists = new ArrayList<>();
    public static List<Song> listSongs = new ArrayList<>();
    public static List<Album> listAlbums = new ArrayList<>();

    @PostConstruct
    public void init() {

        listArtists.add(new Artist(1L, "Zeljko", "Joksimovic", "Bio Zeljko"));
        listArtists.add(new Artist(2L, "Lepa", "Brena", "Bio Brena"));
        listArtists.add(new Artist(3L, "Aca", "Lukas", "Bio Aca"));
        listArtists.add(new Artist(4L, "Svetlana", "Raznatovic", "Bio Ceca"));
        listArtists.add(new Artist(5L, "Toma", "Zdravkovic", "Bio Toma"));

        listAlbums = new ArrayList<>();
        listAlbums.add(new Album("Single", "Pop", "1999"));
        listAlbums.add(new Album("Luda za tobom", "Turbo-folk", "1989"));
        listAlbums.add(new Album("Single", "Turbo-folk", "2006"));
        listAlbums.add(new Album("Single", "Turbo-folk", "2010"));
        listAlbums.add(new Album("Ponoc", "Folk", "1997"));

        listSongs.add(new Song("Lane moje", "Pop", 2016, listAlbums.get(0)));
        listSongs.add(new Song("Luda za tobom", "Turbo-folk", 2017, listAlbums.get(1)));
        listSongs.add(new Song("Suncokreti", "Turbo-folk", 2019, listAlbums.get(2)));
        listSongs.add(new Song("Trepni", "Turbo-folk", 2015, listAlbums.get(3)));
        listSongs.add(new Song("Ponoc", "Folk", 2018, listAlbums.get(4)));
    }
}