package mk.ukim.finki.wp.lab.service.impl;

import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.repository.InMemoryAlbumRepository;
import mk.ukim.finki.wp.lab.service.AlbumService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AlbumServiceImpl implements AlbumService {

    private final InMemoryAlbumRepository inMemoryAlbumRepository;

    public AlbumServiceImpl(InMemoryAlbumRepository inMemoryAlbumRepository) {
        this.inMemoryAlbumRepository = inMemoryAlbumRepository;
    }

    @Override
    public List<Album> findAll() {
        return inMemoryAlbumRepository.findAll();
    }

    @Override
    public Optional<Album> findById(Long albumId) {
        return inMemoryAlbumRepository.findAlbumById(albumId);
    }
}
